### Dependencias:
- @fortawesome/fontawesome-free
- jquery-toast-plugin
- select2
- sweetalert2
- vue-js-toggle-button
- vue-numeric
- vue-router
- vue-select
- vue2-datepicker
- vue-loader
- vue-native-color-picker


------------

### Security Vulnerabilities
- Dashboard: **[TABLER](https://tabler.io/)**
- Bootstrap 5 misma plantilla *No dependencia*
- Laravel 8 *(scaffolding auth)*
- Vue.js 2.6

------------
*NOTA*: ***Al realizar una nueva actuliazacion del sistema una vez concluido desplegarlo en una nueva rama***
