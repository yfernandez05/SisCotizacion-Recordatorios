<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="user" content="<?php echo e(Auth::user()); ?>">

<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
<title><?php echo e(config('app.name')); ?> <?php echo $__env->yieldContent('title','- Sistema de Servicios'); ?></title><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\SisCotizacion\sistemaCotizacion\resources\views/layouts/partials/_head.blade.php ENDPATH**/ ?>