<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php $__env->startSection('head'); ?>
        <?php echo $__env->make('layouts.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      

        <!-- Fonts -->
        <!-- <link rel="dns-prefetch" href="//fonts.gstatic.com"> -->
        <!-- <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"> -->

        <!-- Styles -->
        <link href="<?php echo e(asset('css/tabler.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/demotabler.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style_font.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/tabler-vendors.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldSection(); ?>
    

    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <div>
        <?php echo $__env->make('layouts.partials._preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main-wrapper">
            <?php echo $__env->make('layouts.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('layouts.partials._siderbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <main class="page-body">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
    
            <div class="footer-cont">
                <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/tabler.js')); ?>" defer></script>

    <?php echo $__env->yieldContent('js'); ?>
    
</body>
</html>
<?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\SisCotizacion\sistemaCotizacion\resources\views/layouts/app.blade.php ENDPATH**/ ?>