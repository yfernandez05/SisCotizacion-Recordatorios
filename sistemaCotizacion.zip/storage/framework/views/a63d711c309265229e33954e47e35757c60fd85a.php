

<?php $__env->startSection('content'); ?>
    <router-view></router-view>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\SisCotizacion\sistemaCotizacion\resources\views/spa.blade.php ENDPATH**/ ?>