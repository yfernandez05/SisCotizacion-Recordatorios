<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php $__env->startSection('head'); ?>
        <?php echo $__env->make('layouts.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/tabler.js')); ?>" defer></script>
        <!-- Styles -->
        <link href="<?php echo e(asset('css/tabler.css')); ?>" rel="stylesheet">
        <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> -->
        <link href="<?php echo e(asset('css/style_font.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldSection(); ?>
    

    <?php echo $__env->yieldContent('style'); ?>
    <style>
        body{
            overflow-y:auto !important;
        }
    </style>
</head>
<body>
    <div>
        <?php echo $__env->make('layouts.partials._preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main-wrapper">
            <main class="">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\SisCotizacion\sistemaCotizacion\resources\views/layouts/auth.blade.php ENDPATH**/ ?>