<?php $__env->startSection('title', '- Inicio de Sesión'); ?>

<?php $__env->startSection('style'); ?>
<style>
  .theme-dark .row.g-0.flex-fill.bg-white{
    /* --tblr-white-rgb : */
    background-color: #1a2234 !important;
  }
  .row.g-0.flex-fill.bg-white{
    height: 100vh;
  }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row g-0 flex-fill bg-white">
      <div class="col-12 col-lg-6 col-xl-4 border-top-wide border-primary d-flex flex-column justify-content-center">
        <div class="container container-tight my-5 px-lg-5">
          <div class="text-center mb-4">
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand navbar-brand-autodark"><img src="<?php echo e(asset('images/logo.png')); ?>" height="55" alt=""></a>
          </div>
          <h2 class="h3 text-center mb-3">
            Ingrese a su cuenta
          </h2>
          <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="email" class="col-form-label"><?php echo e(__('Correo electronico')); ?></label>
              <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-2">
              <label class="form-label">
                <?php echo e(__('Contraseña')); ?>

                <span class="form-label-description">
                  <?php if(Route::has('password.request')): ?>
                      <a class="" href="<?php echo e(route('password.request')); ?>">
                          <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

                      </a>
                  <?php endif; ?>
                </span>
              </label>
              
              <div class="input-group input-group-flat">
              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Su contraseña">
                <span class="input-group-text">
                  <a href="#" class="link-secondary" title="Mostrar Constraseña" data-bs-toggle="tooltip" onclick="showPassword()">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" /><path d="M22 12c-2.667 4.667 -6 7 -10 7s-7.333 -2.333 -10 -7c2.667 -4.667 6 -7 10 -7s7.333 2.333 10 7" /></svg>
                  </a>
                </span>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="mb-2">
              <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                  <label class="form-check-label" for="remember">
                      <?php echo e(__('Recuérdame')); ?>

                  </label>
              </div>
            </div>
            <div class="form-footer">
              <button type="submit" class="btn btn-primary w-100">
                  <?php echo e(__('Iniciar Sesión')); ?>

              </button>
            </div>
          </form>
          
        </div>
      </div>
      <div class="col-12 col-lg-6 col-xl-8 d-none d-lg-block">
        <!-- Photo -->
        <div class="bg-cover h-100 min-vh-100 login-cover"></div>
      </div>
    </div>
    <script>
  function showPassword() {
    var passwordField = document.getElementById("password");
    passwordField.type = (passwordField.type === "password") ? "text" : "password";
  }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\SisCotizacion\sistemaCotizacion\resources\views/auth/login.blade.php ENDPATH**/ ?>