<div class="preloader" id="preloader">
    <span class="loader"></span>
    <p class="loader__label text-white">CRM</p>
</div><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\SisCotizacion\sistemaCotizacion\resources\views/layouts/partials/_preloader.blade.php ENDPATH**/ ?>