<footer class="footer footer-transparent d-print-none col">
    <div class="container-xl">
        <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item">
                        Copyright © 2023
                        <a href="https://www.padinsolutions.com/" class="link-secondary">Padin Solutions</a>.
                        Reservados todos los derechos.
                    </li>
                    <li class="list-inline-item">
                        <a class="link-secondary" rel="noopener">
                            v1.0.0
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\SisCotizacion\sistemaCotizacion\resources\views/layouts/partials/_footer.blade.php ENDPATH**/ ?>