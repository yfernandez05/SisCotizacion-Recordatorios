<div class="preloader" id="preloader">
    <span class="loader"></span>
    <p class="loader__label text-white">CRM</p>
</div>